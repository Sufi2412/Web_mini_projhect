<ul>
    <li><a href="index.php">home</a></li>
    <li><a href="?a=student_add">admission</a></li>
    <li><a href="?a=view">students</a></li>
        <li><a href="">contact us</a></li>
</ul>
